package com.example.kamvardinaexpress;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class GhanonCheck extends AppCompatActivity {

    PDFView pdfViewTegarat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ghanon_check);

        pdfViewTegarat = findViewById(R.id.check_pdf);
        pdfViewTegarat.fromAsset("check_law.pdf").load();

    }
}
