package com.example.kamvardinaexpress;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class TegaratElectronic extends AppCompatActivity {

    PDFView pdfViewElectronic;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tegarat_electronic);

        pdfViewElectronic = findViewById(R.id.electronicpdf);

        pdfViewElectronic.fromAsset("electronic_law.pdf").load();
    }
}
