package com.example.kamvardinaexpress;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<ghanon> imageModelArrayList;
    private ghanonAdapter adapter;

    private int[] myImageList = new int[]{R.drawable.margaa, R.drawable.civil_law,R.drawable.criminal_law, R.drawable.economy_law,R.drawable.employee_law,R.drawable.work_law,R.drawable.tax_law,R.drawable.registry_law,R.drawable.militarylaw,R.drawable.lawyer_law,R.drawable.family_law};
    private String[] myImageNameList = new String[]{"قوانین مرجع","حقوق مدنی" ,"جزا" ,"تجارت" ,"استخدام","کار","مالیات","ثبت","نیروهای مسلح" , "وکالت" ,"خانواده"};


    private RecyclerView recyclerView2;
    private ArrayList<sana> imageModelArrayList2;
    private sanaAdapter adapter2;
    private int[] myImageList2 = new int[]{R.drawable.sana_eblagh, R.drawable.sana_vkala,R.drawable.sna_ashkhas,R.drawable.sana_sabtename};
    private String[] myImageNameList2 = new String[]{"ابلاغ" ,"اطلاع رسانی وکلا" , "اطلاع رسانی اشخاص" ,"ثبت نام ثنا"};

    private RecyclerView recyclerView3;
    private ArrayList<khabargozari> imageModelArrayList3;
    private KhabargozariAdapter adapter3;
    private int[] myImageList3 = new int[]{R.drawable.kamvaricond, R.drawable.mizan,R.drawable.isna,R.drawable.farse ,R.drawable.tabnak,R.drawable.press,R.drawable.navad};
    private String[] myImageNameList3 = new String[]{"کامور دینا" , "میزان" ,"ایسنا"   ,"فارس" , "تابناک" , "PressTV" , "نود"};


    private RecyclerView recyclerView4;
    private ArrayList<tools> imageModelArrayList4;
    private toolsAdapter adapter4;
    private int[] myImageList4 = new int[]{R.drawable.mehrieh, R.drawable.nim,R.drawable.davari_aaa,R.drawable.karshenasi_aa };
    private String[] myImageNameList4 = new String[]{"محاسبه مهریه" , "محاسبه نیم عشر" ,"محاسبه داوری" ,"محاسبه کارشناسی" };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setCustomView(R.layout.custom_action_bar);
        //getSupportActionBar().setElevation(0);
        View view = getSupportActionBar().getCustomView();
        TextView name = view.findViewById(R.id.name);
//        name.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(MainActivity.this, "You have clicked tittle", Toast.LENGTH_LONG).show();
//            }
//        });
        recyclerView = (RecyclerView) findViewById(R.id.recycler);

        imageModelArrayList = ghanon();
        adapter = new ghanonAdapter(this, imageModelArrayList);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, true));
        recyclerView2 = (RecyclerView) findViewById(R.id.recycler2);

        imageModelArrayList2 = sana();
        adapter2 = new sanaAdapter(this, imageModelArrayList2);
        recyclerView2.setAdapter(adapter2);
        recyclerView2.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, true));


        recyclerView3 = (RecyclerView) findViewById(R.id.recycler3);
        imageModelArrayList3 = khabargozari();
        adapter3 = new KhabargozariAdapter(this, imageModelArrayList3);
        recyclerView3.setAdapter(adapter3);
        recyclerView3.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, true));

        recyclerView4 = (RecyclerView) findViewById(R.id.recycler4);
        imageModelArrayList4 = tools();
        adapter4 = new toolsAdapter(this, imageModelArrayList4);
        recyclerView4.setAdapter(adapter4);
        recyclerView4.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, true));




    }
    private ArrayList<ghanon> ghanon() {

        ArrayList<ghanon> list = new ArrayList<>();

        for (int i = 0; i < 11; i++) {
            ghanon Model = new ghanon();
            Model.setName(myImageNameList[i]);
            Model.setImage_drawable(myImageList[i]);
            list.add(Model);
        }

        return list;
    }

        private ArrayList<sana> sana(){

            ArrayList<sana> list = new ArrayList<>();

            for(int i = 0; i < 4; i++){
                sana Model = new sana();
                Model.setName(myImageNameList2[i]);
                Model.setImage_drawable(myImageList2[i]);
                list.add(Model);
            }

            return list;
    }

    private ArrayList<khabargozari> khabargozari(){

        ArrayList<khabargozari> list = new ArrayList<>();

        for(int i = 0; i < 7; i++){
            khabargozari Model = new khabargozari();
            Model.setName(myImageNameList3[i]);
            Model.setImage_drawable(myImageList3[i]);
            list.add(Model);
        }

        return list;
    }

    private ArrayList<tools> tools(){

        ArrayList<tools> list = new ArrayList<>();

        for(int i = 0; i < 4; i++){
            tools Model = new tools();
            Model.setName(myImageNameList4[i]);
            Model.setImage_drawable(myImageList4[i]);
            list.add(Model);
        }

        return list;
    }

//    private ArrayList<khadamat> khadamat(){
//
//        ArrayList<khadamat> list = new ArrayList<>();
//
//        for(int i = 0; i < 1; i++){
//            khadamat Model = new khadamat();
//            Model.setName(myImageNameList4[i]);
//
//            list.add(Model);
//        }
//
//        return list;
//    }
}
