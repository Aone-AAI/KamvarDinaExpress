package com.example.kamvardinaexpress;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class GhanonTegaratActivity extends AppCompatActivity {

    PDFView pdfViewTegarat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ghanon_tegarat);

        pdfViewTegarat = findViewById(R.id.new_pdftegarat);

        pdfViewTegarat.fromAsset("new_tegarat.pdf").load();
    }
}
