package com.example.kamvardinaexpress;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class AeinNameDavari_Activity extends AppCompatActivity {
    PDFView pdfView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aein_name_davari_);

        pdfView = findViewById(R.id.aein_name_dadrasi);
        pdfView.fromAsset("davari.pdf").load();
    }
}
