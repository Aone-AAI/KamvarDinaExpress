package com.example.kamvardinaexpress;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class ISNA_Activity extends AppCompatActivity {
    WebView webViewsiteisna;
    Activity activityisna;
    private ProgressDialog progDailogisna;

    @Override
    public void onBackPressed() {
        if (webViewsiteisna.canGoBack()) {
            webViewsiteisna.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_isna_);


        if (Build.VERSION.SDK_INT >= 19) {


            if (!DetectConnection.checkInternetConnection(this)) {
                Toast.makeText(getApplicationContext(), "No Internet!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                webViewsiteisna = findViewById(R.id.isna_site);
                CustomWebViewClientisna c = new CustomWebViewClientisna();
                webViewsiteisna.setLayerType(View.LAYER_TYPE_HARDWARE, null);
                webViewsiteisna.setWebViewClient(c);
                webViewsiteisna.clearCache(true);
                webViewsiteisna.clearHistory();
                activityisna = this;
                progDailogisna = ProgressDialog.show(activityisna, "Loading", "Please wait...", true);
                progDailogisna.setCancelable(false);
                webViewsiteisna.getSettings().setJavaScriptEnabled(true);
                webViewsiteisna.getSettings().setLoadWithOverviewMode(true);
                webViewsiteisna.getSettings().setUseWideViewPort(true);
                webViewsiteisna.setWebViewClient(new WebViewClient() {

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        progDailogisna.show();
                        view.loadUrl(url);
                        return true;
                    }

                    @Override
                    public void onPageFinished(WebView view, final String url) {
                        if (progDailogisna.isShowing()) {
                            progDailogisna.dismiss();
                        }

                    }
                });

                webViewsiteisna.loadUrl("http://www.isna.ir");
            }



        }
        else {


            if (!DetectConnection.checkInternetConnection(this)) {
                Toast.makeText(getApplicationContext(), "No Internet!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                webViewsiteisna = findViewById(R.id.isna_site);
                CustomWebViewClientisna c = new CustomWebViewClientisna();
                webViewsiteisna.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                webViewsiteisna.setWebViewClient(c);
                webViewsiteisna.clearCache(true);
                webViewsiteisna.clearHistory();
                activityisna = this;
                progDailogisna = ProgressDialog.show(activityisna, "Loading", "Please wait...", true);
                progDailogisna.setCancelable(false);
                webViewsiteisna.getSettings().setJavaScriptEnabled(true);
                webViewsiteisna.getSettings().setLoadWithOverviewMode(true);
                webViewsiteisna.getSettings().setUseWideViewPort(true);
                webViewsiteisna.setWebViewClient(new WebViewClient() {

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        progDailogisna.show();
                        view.loadUrl(url);

                        return true;
                    }

                    @Override
                    public void onPageFinished(WebView view, final String url) {

                        if (progDailogisna.isShowing()) {
                            progDailogisna.dismiss();
                        }

                    }
                });

                webViewsiteisna.loadUrl("http://www.isna.ir");
            }

        }



// Function to load all URLs in same webview

    }


    private class CustomWebViewClientisna extends WebViewClient {
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (!DetectConnection.checkInternetConnection(ISNA_Activity.this)) {
                Toast.makeText(getApplicationContext(), "No Internet!", Toast.LENGTH_SHORT).show();
            } else {
                view.loadUrl(url);
            }
            return true;
        }
    }
}