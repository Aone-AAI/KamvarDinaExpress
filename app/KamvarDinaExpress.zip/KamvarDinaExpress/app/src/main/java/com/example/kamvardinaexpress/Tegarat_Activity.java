package com.example.kamvardinaexpress;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.github.barteksc.pdfviewer.PDFView;

public class Tegarat_Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tegarat_);


    }

    public void ghanon_check(View view) {

        Intent intent = new Intent(this,GhanonCheck.class);
        startActivity(intent);
    }

    public void tegarat_electronic(View view) {

        Intent intent = new Intent(this,TegaratElectronic.class);
        startActivity(intent);
    }


    public void tegarat(View view) {

        Intent intent = new Intent(this,GhanonTegaratActivity.class);
        startActivity(intent);
    }
}
