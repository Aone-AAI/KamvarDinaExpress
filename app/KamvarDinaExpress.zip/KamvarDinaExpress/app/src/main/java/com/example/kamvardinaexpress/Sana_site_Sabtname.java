package com.example.kamvardinaexpress;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class Sana_site_Sabtname extends AppCompatActivity {

    WebView webViewsite;
    Activity activity;
    private ProgressDialog progDailog;


    @Override
    public void onBackPressed() {

        if (webViewsite.canGoBack()) {
            webViewsite.goBack();
        } else {
            super.onBackPressed();
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sana_site__sabtname);

        if (Build.VERSION.SDK_INT >= 19) {


            if (!DetectConnection.checkInternetConnection(this)) {
                Toast.makeText(getApplicationContext(), "No Internet!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                webViewsite = findViewById(R.id.Sana_sabte_name);
                CustomWebViewClient c = new CustomWebViewClient();
                webViewsite.setLayerType(View.LAYER_TYPE_HARDWARE, null);
                webViewsite.setWebViewClient(c);
                webViewsite.clearCache(true);
                webViewsite.clearHistory();
                activity = this;
                progDailog = ProgressDialog.show(activity, "Loading","Please wait...", true);
                progDailog.setCancelable(false);
                webViewsite.getSettings().setJavaScriptEnabled(true);
                webViewsite.getSettings().setLoadWithOverviewMode(true);
                webViewsite.getSettings().setUseWideViewPort(true);
                webViewsite.setWebViewClient(new WebViewClient(){

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        progDailog.show();
                        view.loadUrl(url);

                        return true;
                    }
                    @Override
                    public void onPageFinished(WebView view, final String url) {
                        if (progDailog.isShowing()) {
                            progDailog.dismiss();
                        }
                    }
                });

                webViewsite.loadUrl("http://sana.adliran.ir/Sana/Index#/Main");
            }





        }
        else {


            if (!DetectConnection.checkInternetConnection(this)) {
                Toast.makeText(getApplicationContext(), "No Internet!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                webViewsite = findViewById(R.id.Sana_sabte_name);
                CustomWebViewClient c = new CustomWebViewClient();
                webViewsite.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                webViewsite.setWebViewClient(c);
                webViewsite.clearCache(true);
                webViewsite.clearHistory();
                activity = this;
                progDailog = ProgressDialog.show(activity, "Loading","Please wait...", true);
                progDailog.setCancelable(false);
                webViewsite.getSettings().setJavaScriptEnabled(true);
                webViewsite.getSettings().setLoadWithOverviewMode(true);
                webViewsite.getSettings().setUseWideViewPort(true);
                webViewsite.setWebViewClient(new WebViewClient(){

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        progDailog.show();
                        view.loadUrl(url);

                        return true;
                    }
                    @Override
                    public void onPageFinished(WebView view, final String url) {


                        if (progDailog.isShowing()) {
                            progDailog.dismiss();
                        }
                    }
                });
                webViewsite.loadUrl("http://sana.adliran.ir/Sana/Index#/Main");
            }
        }

    }
    private class CustomWebViewClient extends WebViewClient {
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (!DetectConnection.checkInternetConnection(Sana_site_Sabtname.this)) {
                Toast.makeText(getApplicationContext(), "No Internet!", Toast.LENGTH_SHORT).show();
            } else {
                view.loadUrl(url);
            }
            return true;
        }
    }
}
